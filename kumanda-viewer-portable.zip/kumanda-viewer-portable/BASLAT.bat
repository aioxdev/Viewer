@echo off
REM Kumanda Teknigi Viewer - npm GEREKTIRMEZ, sadece python yeterli.
REM Cift tikla calisir. Kapatmak icin bu pencereyi kapat.
cd /d "%~dp0web"
where py >nul 2>nul
if %errorlevel%==0 (set PY=py) else (set PY=python)
for /f %%i in ('%PY% -c "import socket;s=socket.socket();s.bind(('127.0.0.1',0));print(s.getsockname()[1])"') do set PORT=%%i
start "" "http://127.0.0.1:%PORT%/"
%PY% -m http.server %PORT%
