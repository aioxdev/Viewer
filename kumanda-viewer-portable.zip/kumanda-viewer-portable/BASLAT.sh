#!/bin/bash
# Kumanda Tekniği Viewer - npm GEREKTİRMEZ, sadece python3 yeterli.
# Çift tıkla çalışır. Kapatmak için bu pencereyi kapat.
cd "$(dirname "$0")/web" || exit 1
PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1])')
python3 -m http.server "$PORT" >/dev/null 2>&1 &
SRV=$!
trap "kill $SRV 2>/dev/null" EXIT
sleep 1
(xdg-open "http://127.0.0.1:$PORT/" 2>/dev/null || open "http://127.0.0.1:$PORT/" 2>/dev/null) &
echo "Kumanda Viewer acildi: http://127.0.0.1:$PORT/"
echo "Kapatmak icin bu pencereyi kapat (Ctrl+C)."
wait $SRV
